s = tf('s');
P_sys= (2.35655*s/(s^3+0.00883167*s^2-27.9169*s-2.30942));
Kp = 100;
Ki = 10;
Kd = 10;
%C = pid(Kp,Ki,Kd);
%T = feedback(P_sys,C);
%t=0:0.01:10;
%step(T)
pzplot(P_sys)